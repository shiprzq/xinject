/*
 * Xinject Injector — ptrace-based dlopen injection for Roblox Android
 *
 * Method: register-based remote function call
 *   1. PTRACE_ATTACH + wait for stop
 *   2. Save target's registers
 *   3. Write .so path string to target's stack
 *   4. Set up registers: x0=path, x1=RTLD_NOW, pc=dlopen, lr=0
 *   5. PTRACE_CONT — target calls dlopen, crashes at LR=0
 *   6. Wait for SIGSEGV, read x0 for dlopen return value
 *   7. Restore all registers (incl. PC) so target resumes normally
 *   8. PTRACE_DETACH
 *
 * Payload constructor runs automatically when dlopen loads the .so.
 *
 * Compile: ./build.sh
 * Usage:   ./injector <pid> <path_to_payload.so>
 */

#define _GNU_SOURCE
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dlfcn.h>
#include <link.h>

/* ---- ARM64 register definitions ---- */
struct user_regs {
    unsigned long regs[31];  /* x0-x30 */
    unsigned long sp;
    unsigned long pc;
    unsigned long pstate;
};

/* ---- Memory read/write via process_vm_readv/writev ---- */
static int mem_read(pid_t pid, unsigned long addr, void* buf, size_t len) {
    struct iovec local  = { .iov_base = buf, .iov_len = len };
    struct iovec remote = { .iov_base = (void*)addr, .iov_len = len };
    ssize_t n = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)len) ? 0 : -1;
}

static int mem_write(pid_t pid, unsigned long addr, const void* buf, size_t len) {
    struct iovec local  = { .iov_base = (void*)buf, .iov_len = len };
    struct iovec remote = { .iov_base = (void*)addr, .iov_len = len };
    ssize_t n = process_vm_writev(pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)len) ? 0 : -1;
}

/* ---- Register get/set via PTRACE_GETREGSET ---- */
static int get_regs(pid_t pid, struct user_regs* regs) {
    struct iovec iov = { .iov_base = regs, .iov_len = sizeof(*regs) };
    return ptrace(PTRACE_GETREGSET, pid, (void*)NT_PRSTATUS, &iov);
}

static int set_regs(pid_t pid, struct user_regs* regs) {
    struct iovec iov = { .iov_base = regs, .iov_len = sizeof(*regs) };
    return ptrace(PTRACE_SETREGSET, pid, (void*)NT_PRSTATUS, &iov);
}

/* ---- Find library base in target's /proc/pid/maps ---- */
static unsigned long find_lib_base(pid_t pid, const char* libname) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* f = fopen(path, "r");
    if (!f) return 0;

    unsigned long base = 0;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        /* Match libname in path AND executable (r-xp) mapping */
        if (strstr(line, libname) && strstr(line, "r-xp")) {
            sscanf(line, "%lx-", &base);
            break;
        }
    }
    fclose(f);
    return base;
}

/*
 * Find the base address of a library loaded in OUR process.
 * Uses dl_iterate_phdr for accurate base address (not the dlopen handle).
 */
struct find_data {
    const char* name;
    unsigned long base;
};

static int find_base_cb(struct dl_phdr_info* info, size_t size, void* data) {
    (void)size;
    struct find_data* fd = (struct find_data*)data;
    if (strstr(info->dlpi_name, fd->name)) {
        fd->base = info->dlpi_addr;
        return 1; /* stop */
    }
    return 0;
}

static unsigned long get_local_base(const char* libname) {
    struct find_data fd = { .name = libname, .base = 0 };
    dl_iterate_phdr(find_base_cb, &fd);
    return fd.base;
}

/*
 * Resolve a function address in the remote process.
 *
 * Computes: remote_func = remote_lib_base + (local_func - local_lib_base)
 * Both bases come from /proc/pid/maps and dl_iterate_phdr respectively —
 * NOT from dlopen handles.
 */
static unsigned long remote_func(pid_t pid, const char* libname, const char* funcname) {
    /* Get function address in our own process */
    void* local_func = dlsym(RTLD_DEFAULT, funcname);
    if (!local_func) {
        void* h = dlopen(libname, RTLD_LAZY);
        if (!h) return 0;
        local_func = dlsym(h, funcname);
        dlclose(h);
        if (!local_func) return 0;
    }

    /* Get library base in our process */
    unsigned long local_base = get_local_base(libname);
    if (!local_base) return 0;

    /* Offset = function - base (in our process) */
    unsigned long offset = (unsigned long)local_func - local_base;

    /* Find library base in target process */
    unsigned long remote_base = find_lib_base(pid, libname);
    if (!remote_base) return 0;

    return remote_base + offset;
}

/*
 * Inject by calling dlopen(path, RTLD_NOW) in the target process.
 *
 *   1. Write the .so path to target's stack (4KB below SP)
 *   2. Set regs: x0=path, x1=RTLD_NOW(2), pc=dlopen, lr=0
 *   3. Resume target — it calls dlopen, then crashes at LR=0
 *   4. Wait for SIGSEGV, read return value from x0
 *   5. Restore original registers so target continues normally
 */
static int inject(pid_t pid, const char* so_path) {
    struct user_regs saved_regs, call_regs;
    size_t path_len = strlen(so_path) + 1;

    /* 1. Save target's original state */
    if (get_regs(pid, &saved_regs) < 0) {
        perror("get_regs (save)");
        return -1;
    }

    /* 2. Resolve dlopen in target */
    unsigned long remote_dlopen = remote_func(pid, "libdl.so", "dlopen");
    if (!remote_dlopen) {
        /* Some Android versions have dlopen in libc */
        remote_dlopen = remote_func(pid, "libc.so", "dlopen");
    }
    if (!remote_dlopen) {
        fprintf(stderr, "[-] Could not resolve remote dlopen\n");
        return -1;
    }
    printf("[+] Remote dlopen: 0x%lx\n", remote_dlopen);

    /* 3. Write .so path to target stack */
    unsigned long path_addr = (saved_regs.sp - 4096) & ~0x7UL;
    if (mem_write(pid, path_addr, so_path, path_len) < 0) {
        perror("mem_write path");
        return -1;
    }
    printf("[+] Wrote path string to 0x%lx\n", path_addr);

    /* 4. Set up call registers */
    memcpy(&call_regs, &saved_regs, sizeof(call_regs));
    call_regs.regs[0]  = path_addr;        /* x0 = path */
    call_regs.regs[1]  = 2;                /* x1 = RTLD_NOW */
    call_regs.pc       = remote_dlopen;    /* pc = dlopen */
    call_regs.regs[30] = 0;                /* lr = 0 → SIGSEGV on return */

    if (set_regs(pid, &call_regs) < 0) {
        perror("set_regs (call)");
        return -1;
    }

    /* 5. Resume target — it will call dlopen then crash */
    if (ptrace(PTRACE_CONT, pid, NULL, NULL) < 0) {
        perror("PTRACE_CONT");
        set_regs(pid, &saved_regs);
        return -1;
    }

    int status;
    if (waitpid(pid, &status, 0) < 0) {
        perror("waitpid");
        set_regs(pid, &saved_regs);
        return -1;
    }

    if (!WIFSTOPPED(status)) {
        fprintf(stderr, "[-] Target did not stop (status=0x%x)\n", status);
        set_regs(pid, &saved_regs);
        return -1;
    }

    /* 6. Read dlopen return value from x0 */
    struct user_regs post_call;
    if (get_regs(pid, &post_call) < 0) {
        perror("get_regs (post-call)");
        set_regs(pid, &saved_regs);
        return -1;
    }

    unsigned long dlopen_ret = post_call.regs[0];
    printf("[+] dlopen returned: 0x%lx\n", dlopen_ret);

    /* 7. Restore original registers (PC points where thread was) */
    if (set_regs(pid, &saved_regs) < 0) {
        perror("set_regs (restore)");
        return -1;
    }

    if (dlopen_ret == 0) {
        fprintf(stderr, "[-] dlopen returned NULL — check payload path and architecture\n");
        return -1;
    }

    return 0;
}

/* ---- Main ---- */
int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <pid> <path_to_payload.so>\n", argv[0]);
        fprintf(stderr, "  e.g. %s 12345 /data/local/tmp/libxinject_payload.so\n", argv[0]);
        return 1;
    }

    pid_t pid = (pid_t)atoi(argv[1]);
    const char* so_path = argv[2];

    if (access(so_path, F_OK) != 0) {
        fprintf(stderr, "[-] File not found: %s\n", so_path);
        return 1;
    }

    printf("[*] Target PID:  %d\n", pid);
    printf("[*] Payload:     %s\n", so_path);

    /* Attach to target */
    if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) < 0) {
        perror("PTRACE_ATTACH");
        fprintf(stderr, "[-] Attach failed. Is the device rooted? Try: adb shell setenforce 0\n");
        return 1;
    }

    int status;
    if (waitpid(pid, &status, 0) < 0) {
        perror("waitpid (attach)");
        ptrace(PTRACE_DETACH, pid, NULL, NULL);
        return 1;
    }

    printf("[+] Attached to PID %d\n", pid);

    /* Inject the payload */
    int result = inject(pid, so_path);

    /* Detach */
    if (ptrace(PTRACE_DETACH, pid, NULL, NULL) < 0) {
        perror("PTRACE_DETACH");
        return 1;
    }

    if (result == 0) {
        printf("[+] Injection successful\n");
        printf("[*] Check result: adb shell cat /data/local/tmp/xinject_result.txt\n");
    } else {
        fprintf(stderr, "[-] Injection failed\n");
        return 1;
    }

    return 0;
}
