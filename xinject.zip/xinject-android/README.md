# Xinject Android

Roblox Android executor injector. ptrace-based injection, lua_State capture via ARM64 inline hook, clipboard + executor identification functions.

## Architecture

```

xinject-android/
├── injector/               # Standalone ptrace injector binary
│   ├── injector.c          # Core injection — register-based remote dlopen
│   └── build.sh            # Cross-compile script (ARM64)
├── payload/                # Injected .so (runs inside Roblox process)
│   ├── payload.c           # Entry point + hook installer
│   ├── trampoline.S        # ARM64 trampoline (no stack exec, W^X safe)
│   ├── lua_bridge.c        # Register C functions into Lua VM
│   ├── clipboard.c         # Android clipboard via JNI
│   ├── payload.h           # Shared header
│   └── build.sh            # Cross-compile script (ARM64)
├── lua/                    # Roblox-side test scripts
│   └── test_ui.lua         # GUI injection test
├── Makefile                # Top-level build
└── README.md               # This file

```

## Requirements

- Rooted Android device (or emulator with root + SELinux permissive)
- Android NDK r26+
- adb + USB debugging enabled
- Roblox installed and running

## Build

```bash
export ANDROID_NDK_HOME=/path/to/android-ndk-r26
make all
```

## Deploy & Execute

```
make deploy
adb shell pidof com.roblox.client        # note the PID
adb shell /data/local/tmp/injector <PID> /data/local/tmp/libxinject_payload.so
adb shell cat /data/local/tmp/xinject_result.txt
```

Expected output: `[SUCCESS] lua_State: 0x... | functions registered`

## Exposed Lua Functions (in Roblox)

| Function ↕▾ | Signature ↕▾ | Description ↕▾ |
|---|---|---|
| −`setclipboard(text)` | `(string) → bool` | Sets Android system clipboard |
| −`getclipboard()` | `() → string` | Gets clipboard contents |
| −`identifyexecutor()` | `() → string` | Returns `"Xinject"` |
| −`getexecutorversion()` | `() → string` | Returns `"1.0.0"` |
⚙

## Troubleshooting

| Problem ↕▾ | Fix ↕▾ |
|---|---|
| −ptrace attach failed | `adb shell setenforce 0` |
| −dlopen returned 0 | Verify payload is on device and compiled for ARM64 |
| Functions not registered | Check Lua library name: `adb shell cat /proc/<pid>/maps | grep -E "roblox|lua"` |
| Clipboard functions crash | Ensure JNI is available (Roblox process has a JVM) |
| Hook fires but capture fails | Verify `lua_gettop` is exported: `adb shell cat /proc/<pid>/maps` and check library |
⚙

