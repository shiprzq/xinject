#ifndef XINJECT_PAYLOAD_H
#define XINJECT_PAYLOAD_H

#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>

/* -- lua_State capture -- */
extern volatile uintptr_t g_luaState;
extern volatile int       g_ready;

/* -- Called from trampoline.S with lua_State* in x0 -- */
void capture_lua_state_on_call(uintptr_t L);

/* -- Lua function registration -- */
int  register_lua_functions(uintptr_t L);

/* -- Clipboard via JNI -- */
int   clipboard_set(const char* text);
char* clipboard_get(void);

/* -- Write result to file -- */
int   write_result_file(const char* fmt, ...);

/* -- Logging macros -- */
#define LOG_TAG "XinjectPayload"
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* -- Hook state (shared with trampoline.S) -- */
extern uint8_t  saved_opcodes[16];
extern void*    hooked_target;
extern void*    return_addr;
extern void     trampoline_entry(void);

#endif
