-- Xinject Test UI — runs inside Roblox after injection
-- Paste this into your executor after a successful injection

local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local UserInputService = game:GetService("UserInputService")
local LocalPlayer = Players.LocalPlayer

-- Create the UI container
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "Xinject"
ScreenGui.ResetOnSpawn = false
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.Parent = CoreGui

local Frame = Instance.new("Frame")
Frame.Size = UDim2.fromOffset(300, 220)
Frame.Position = UDim2.fromScale(0.5, 0.5)
Frame.AnchorPoint = Vector2.new(0.5, 0.5)
Frame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
Frame.BorderSizePixel = 0
Frame.Parent = ScreenGui

Instance.new("UICorner", Frame).CornerRadius = UDim.new(0, 8)

-- Title
local Title = Instance.new("TextLabel")
Title.Size = UDim2.fromOffset(280, 30)
Title.Position = UDim2.fromOffset(10, 10)
Title.BackgroundTransparency = 1
Title.Font = Enum.Font.GothamBold
Title.TextSize = 18
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.Text = "Xinject v1.0.0"
Title.Parent = Frame

-- Status label
local Status = Instance.new("TextLabel")
Status.Size = UDim2.fromOffset(280, 20)
Status.Position = UDim2.fromOffset(10, 45)
Status.BackgroundTransparency = 1
Status.Font = Enum.Font.Gotham
Status.TextSize = 12
Status.TextColor3 = Color3.fromRGB(0, 255, 0)
Status.Text = "Injection OK"
Status.Parent = Frame

-- Helper to set status text
local function setStatus(text, ok)
    Status.Text = text
    Status.TextColor3 = ok and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 0, 0)
end

-- Test setclipboard
local SetBtn = Instance.new("TextButton")
SetBtn.Size = UDim2.fromOffset(280, 40)
SetBtn.Position = UDim2.fromOffset(10, 75)
SetBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
SetBtn.BorderSizePixel = 0
SetBtn.Text = "setclipboard('Hello from Xinject')"
SetBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
SetBtn.Font = Enum.Font.Gotham
SetBtn.TextSize = 13
SetBtn.Parent = Frame
Instance.new("UICorner", SetBtn).CornerRadius = UDim.new(0, 6)

SetBtn.MouseButton1Click:Connect(function()
    local ok, err = pcall(function()
        return setclipboard("Hello from Xinject! " .. os.time())
    end)
    setStatus(ok and "Clipboard set!" or "Error: " .. tostring(err), ok)
end)

-- Test getclipboard
local GetBtn = Instance.new("TextButton")
GetBtn.Size = UDim2.fromOffset(280, 40)
GetBtn.Position = UDim2.fromOffset(10, 125)
GetBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
GetBtn.BorderSizePixel = 0
GetBtn.Text = "getclipboard()"
GetBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
GetBtn.Font = Enum.Font.Gotham
GetBtn.TextSize = 13
GetBtn.Parent = Frame
Instance.new("UICorner", GetBtn).CornerRadius = UDim.new(0, 6)

GetBtn.MouseButton1Click:Connect(function()
    local ok, result = pcall(getclipboard)
    setStatus(ok and ("Clipboard: " .. tostring(result)) or "Error: " .. tostring(result), ok)
end)

-- Test identifyexecutor
local IdBtn = Instance.new("TextButton")
IdBtn.Size = UDim2.fromOffset(135, 40)
IdBtn.Position = UDim2.fromOffset(10, 175)
IdBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
IdBtn.BorderSizePixel = 0
IdBtn.Text = "identifyexecutor()"
IdBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
IdBtn.Font = Enum.Font.Gotham
IdBtn.TextSize = 11
IdBtn.Parent = Frame
Instance.new("UICorner", IdBtn).CornerRadius = UDim.new(0, 6)

IdBtn.MouseButton1Click:Connect(function()
    local ok, result = pcall(identifyexecutor)
    setStatus(ok and ("Executor: " .. tostring(result)) or "Error: " .. tostring(result), ok)
end)

-- Test getexecutorversion
local VerBtn = Instance.new("TextButton")
VerBtn.Size = UDim2.fromOffset(135, 40)
VerBtn.Position = UDim2.fromOffset(155, 175)
VerBtn.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
VerBtn.BorderSizePixel = 0
VerBtn.Text = "getexecutorversion()"
VerBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
VerBtn.Font = Enum.Font.Gotham
VerBtn.TextSize = 10
VerBtn.Parent = Frame
Instance.new("UICorner", VerBtn).CornerRadius = UDim.new(0, 6)

VerBtn.MouseButton1Click:Connect(function()
    local ok, result = pcall(getexecutorversion)
    setStatus(ok and ("Version: " .. tostring(result)) or "Error: " .. tostring(result), ok)
end)

-- Dragging
local dragging = false
local dragStart, startPos

Frame.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or
       input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPos = Frame.Position
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or
                     input.UserInputType == Enum.UserInputType.Touch) then
        local delta = input.Position - dragStart
        Frame.Position = UDim2.new(
            startPos.X.Scale, startPos.X.Offset + delta.X,
            startPos.Y.Scale, startPos.Y.Offset + delta.Y
        )
    end
end)

UserInputService.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 or
       input.UserInputType == Enum.UserInputType.Touch then
        dragging = false
    end
end)

print("[Xinject] Test UI loaded")
