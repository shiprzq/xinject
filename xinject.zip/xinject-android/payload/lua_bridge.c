/*
 * Lua bridge — registers C functions into Roblox's Lua VM
 *
 * Uses Lua C API resolved via dlsym from the already-loaded Lua library.
 * Roblox Android uses a modified Lua 5.1 (sometimes LuaJIT 2.0.x).
 *
 * lua_State struct offsets (ARM64, for reference):
 *   0x10: status     (lu_byte)
 *   0x18: top        (StkId/TValue*)
 *   0x20: base       (StkId/TValue*)
 *   0x28: l_G        (global_State*)
 *   0x30: ci         (CallInfo*)
 *   0x38: stack_last (StkId)
 *   0x40: stack      (StkId)
 *   0x60: errfunc    (int)
 */

#include "payload.h"
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- Function pointer types for Lua C API ---- */
typedef void        (*lua_pushcclosure_fn)(void* L, void* fn, int nup);
typedef void        (*lua_pushstring_fn)(void* L, const char* s);
typedef const char* (*lua_tolstring_fn)(void* L, int idx, size_t* len);
typedef int         (*lua_gettop_fn)(void* L);
typedef void        (*lua_pushboolean_fn)(void* L, int b);
typedef void        (*lua_setglobal_fn)(void* L, const char* name);

/* ---- Resolve Lua API by name from the already-loaded Lua library ---- */
static void* lua_lib = NULL;

static void* get_lua_lib(void) {
    if (lua_lib) return lua_lib;
    lua_lib = dlopen("libroblox.so", RTLD_NOLOAD);
    if (!lua_lib) lua_lib = dlopen("libluajit.so", RTLD_NOLOAD);
    if (!lua_lib) lua_lib = dlopen("libroblox_lua.so", RTLD_NOLOAD);
    return lua_lib;
}

static void* resolve(const char* name) {
    void* lib = get_lua_lib();
    return lib ? dlsym(lib, name) : NULL;
}

/* ---- Registered Lua functions ---- */

/* setclipboard(text) → bool */
static int x_setclipboard(void* L) {
    lua_tolstring_fn   tolstring = (lua_tolstring_fn)resolve("lua_tolstring");
    lua_pushboolean_fn pushbool  = (lua_pushboolean_fn)resolve("lua_pushboolean");

    if (!tolstring || !pushbool) {
        if (pushbool) pushbool(L, 0);
        return 1;
    }

    const char* text = tolstring(L, 1, NULL);
    int result = clipboard_set(text ? text : "");
    pushbool(L, result == 0);
    return 1;
}

/* getclipboard() → string */
static int x_getclipboard(void* L) {
    lua_pushstring_fn pushstr = (lua_pushstring_fn)resolve("lua_pushstring");
    if (!pushstr) return 0;

    char* text = clipboard_get();
    pushstr(L, text ? text : "");
    free(text);
    return 1;
}

/* identifyexecutor() → string */
static int x_identifyexecutor(void* L) {
    lua_pushstring_fn pushstr = (lua_pushstring_fn)resolve("lua_pushstring");
    if (pushstr) pushstr(L, "Xinject");
    return 1;
}

/* getexecutorversion() → string */
static int x_getexecutorversion(void* L) {
    lua_pushstring_fn pushstr = (lua_pushstring_fn)resolve("lua_pushstring");
    if (pushstr) pushstr(L, "1.0.0");
    return 1;
}

/* ---- Register all functions into Lua global table ---- */
int register_lua_functions(uintptr_t L_ptr) {
    void* L = (void*)L_ptr;

    lua_pushcclosure_fn pushc = (lua_pushcclosure_fn)resolve("lua_pushcclosure");
    lua_setglobal_fn    setg  = (lua_setglobal_fn)resolve("lua_setglobal");

    if (!pushc || !setg) {
        LOGE("[-] Cannot resolve lua_pushcclosure or lua_setglobal");
        return -1;
    }

    pushc(L, (void*)x_setclipboard, 0);
    setg(L, "setclipboard");

    pushc(L, (void*)x_getclipboard, 0);
    setg(L, "getclipboard");

    pushc(L, (void*)x_identifyexecutor, 0);
    setg(L, "identifyexecutor");

    pushc(L, (void*)x_getexecutorversion, 0);
    setg(L, "getexecutorversion");

    LOGI("[+] Registered: setclipboard, getclipboard, identifyexecutor, getexecutorversion");
    return 0;
}
