#!/bin/bash
# Build Xinject injector binary for ARM64 Android
# Requires: Android NDK r26+

set -e

NDK="${ANDROID_NDK_HOME:-$HOME/Android/Sdk/ndk/26.3.11579264}"

case "$(uname -s)" in
    Linux)  HOST="linux-x86_64" ;;
    Darwin) HOST="darwin-x86_64" ;;
    *)      echo "[-] Unsupported host OS (expected Linux or macOS)"; exit 1 ;;
esac

TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST"

if [ ! -d "$TOOLCHAIN" ]; then
    echo "[-] NDK toolchain not found at $TOOLCHAIN"
    echo "    Set ANDROID_NDK_HOME to your NDK root directory"
    exit 1
fi

CC="$TOOLCHAIN/bin/aarch64-linux-android33-clang"
SYSROOT="$TOOLCHAIN/sysroot"

echo "[*] Building injector..."

$CC -O2 -s -Wall -static \
    --sysroot="$SYSROOT" \
    -target aarch64-linux-android33 \
    -ldl \
    injector.c \
    -o injector

echo "[+] Build successful: injector"
ls -la injector
