/*
 * Xinject Payload — injected .so for Roblox Android
 *
 * On load:
 *   1. Find the Lua library already loaded in process
 *   2. Inline-hook lua_gettop (or fallback) via trampoline.S
 *   3. First call captures lua_State* from x0 register
 *   4. Register: setclipboard, getclipboard, identifyexecutor, getexecutorversion
 *   5. Write status to /data/local/tmp/xinject_result.txt
 *
 * Compile: ./build.sh (ARM64 only)
 */

#include "payload.h"
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/mman.h>

/* -- Global state -- */
volatile uintptr_t g_luaState = 0;
volatile int       g_ready    = 0;    /* 0=waiting, 1=captured+registered */

/* -- Hook state (referenced by trampoline.S) -- */
uint8_t  saved_opcodes[16];
void*    hooked_target = NULL;
void*    return_addr   = NULL;

/* -- Trampoline entry point (defined in trampoline.S) -- */
extern void trampoline_entry(void);

/* ---- Write result file ---- */
int write_result_file(const char* fmt, ...) {
    char buf[1024];
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    if (n < 0) return -1;

    FILE* f = fopen("/data/local/tmp/xinject_result.txt", "w");
    if (!f) return -1;
    fprintf(f, "%s\n", buf);
    fclose(f);
    return 0;
}

/* ---- Install inline hook at target function ---- */
static int install_hook(void* target) {
    if (!target) return -1;

    /* Save original 16 bytes (4 ARM64 instructions) */
    memcpy(saved_opcodes, target, 16);

    /* Set up shared state for trampoline */
    hooked_target = target;
    return_addr   = (void*)((unsigned long)target + 16);

    /*
     * Build ARM64 patch (8 bytes code + 8 bytes address = 16 bytes total):
     *   LDR X16, #8    — load 64-bit value from PC+8
     *   BR X16         — jump to that address
     *   .quad trampoline_entry
     */
    uint8_t patch[16];
    uintptr_t entry_addr = (uintptr_t)&trampoline_entry;

    *(uint32_t*)(patch + 0) = 0x58000050;   /* LDR X16, #8 */
    *(uint32_t*)(patch + 4) = 0xD61F0200;   /* BR X16 */
    *(uintptr_t*)(patch + 8) = entry_addr;  /* trampoline address */

    /* Make target page writable */
    size_t ps = sysconf(_SC_PAGESIZE);
    uintptr_t page = (uintptr_t)target & ~(ps - 1);
    if (mprotect((void*)page, ps, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        LOGE("[-] mprotect failed: %s", strerror(errno));
        return -1;
    }

    /* Install the hook */
    memcpy(target, patch, sizeof(patch));

    /* Restore original permissions */
    mprotect((void*)page, ps, PROT_READ | PROT_EXEC);

    /* Flush instruction cache — critical on ARM */
    __builtin___clear_cache((char*)target, (char*)target + 16);

    LOGI("[+] Hook installed at %p → trampoline at %p", target, (void*)entry_addr);
    return 0;
}

/* ---- Called from trampoline.S with lua_State* in x0 ---- */
void capture_lua_state_on_call(uintptr_t L) {
    /* Only capture once */
    if (L == 0 || g_ready != 0) return;

    g_luaState = L;
    LOGI("[+] lua_State* captured: 0x%lx", L);

    int ret = register_lua_functions(L);
    if (ret == 0) {
        g_ready = 1;
        write_result_file("[SUCCESS] lua_State: 0x%lx | functions registered", L);
        LOGI("[+] Functions registered successfully. Payload active.");
    } else {
        g_ready = 1;
        write_result_file("[FAIL] lua_State: 0x%lx | registration error %d", L, ret);
        LOGE("[-] Registration failed: %d", ret);
    }
}

/* ---- Constructor — runs automatically on dlopen ---- */
__attribute__((constructor))
void payload_init(void) {
    LOGI("[*] Xinject payload loaded (pid=%d)", getpid());

    /* Find the Lua library already loaded in the target process */
    void* lib = dlopen("libroblox.so", RTLD_NOLOAD);
    if (!lib) lib = dlopen("libluajit.so", RTLD_NOLOAD);
    if (!lib) lib = dlopen("libroblox_lua.so", RTLD_NOLOAD);

    if (!lib) {
        LOGE("[-] No Lua library found in process");
        write_result_file("[FAIL] No Lua library found");
        return;
    }

    /* Find a hookable Lua C API export */
    void* target = dlsym(lib, "lua_gettop");
    if (!target) target = dlsym(lib, "lua_settop");
    if (!target) target = dlsym(lib, "lua_pushnil");
    if (!target) target = dlsym(lib, "lua_type");
    if (!target) target = dlsym(lib, "lua_pushvalue");
    if (!target) target = dlsym(lib, "lua_rawequal");

    if (!target) {
        LOGE("[-] No hookable Lua API export found");
        write_result_file("[FAIL] No Lua API export");
        dlclose(lib);
        return;
    }

    LOGI("[*] Hooking %p", target);
    if (install_hook(target) != 0) {
        write_result_file("[FAIL] Hook installation failed");
    }
    /* lua_State will be captured on next Lua C API call (~100ms) */
}
