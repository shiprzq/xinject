#!/bin/bash
# Build Xinject payload .so for ARM64 Android
# Requires: Android NDK r26+

set -e

NDK="${ANDROID_NDK_HOME:-$HOME/Android/Sdk/ndk/26.3.11579264}"

# Detect host OS for toolchain path
case "$(uname -s)" in
    Linux)  HOST="linux-x86_64" ;;
    Darwin) HOST="darwin-x86_64" ;;
    *)      echo "[-] Unsupported host OS (expected Linux or macOS)"; exit 1 ;;
esac

TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST"

if [ ! -d "$TOOLCHAIN" ]; then
    echo "[-] NDK toolchain not found at $TOOLCHAIN"
    echo "    Set ANDROID_NDK_HOME to your NDK root directory"
    exit 1
fi

CC="$TOOLCHAIN/bin/aarch64-linux-android33-clang"
SYSROOT="$TOOLCHAIN/sysroot"

echo "[*] Building libxinject_payload.so..."

# Assemble trampoline
$CC -c -o trampoline.o trampoline.S \
    --sysroot="$SYSROOT" \
    -target aarch64-linux-android33

# Compile + link all C sources
$CC -fPIC -shared -O2 -s -Wall -Wno-unused-function -Wno-unused-variable \
    --sysroot="$SYSROOT" \
    -target aarch64-linux-android33 \
    -Wl,--hash-style=sysv \
    -Wl,--gc-sections \
    -ldl -llog \
    payload.c \
    lua_bridge.c \
    clipboard.c \
    trampoline.o \
    -o libxinject_payload.so

echo "[+] Build successful: libxinject_payload.so"
ls -la libxinject_payload.so
