/*
 * Android clipboard access via JNI
 *
 * Accesses ClipboardManager from within Roblox process.
 * Roblox already has a JVM attached — we reuse it.
 *
 * Thread safety: attaches native thread to JVM on first use.
 */

#include "payload.h"
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static JavaVM* cached_jvm = NULL;
static int    jvm_queried = 0;

/* Get or cache the JVM pointer */
static JavaVM* get_jvm(void) {
    if (jvm_queried) return cached_jvm;
    jvm_queried = 1;

    JavaVM* vm = NULL;
    jsize count = 0;
    if (JNI_GetCreatedJavaVMs(&vm, 1, &count) != JNI_OK || count == 0) {
        LOGE("[-] No JVM found in process");
        return NULL;
    }
    cached_jvm = vm;
    return vm;
}

/* Get JNIEnv for current thread, attaching if needed */
static JNIEnv* get_env(JavaVM* vm) {
    if (!vm) return NULL;

    JNIEnv* env = NULL;
    jint status = (*vm)->GetEnv(vm, (void**)&env, JNI_VERSION_1_6);

    if (status == JNI_EDETACHED) {
        JavaVMAttachArgs args = {
            .version = JNI_VERSION_1_6,
            .name    = "XinjectClipboard",
            .group   = NULL
        };
        if ((*vm)->AttachCurrentThread(vm, &env, &args) != JNI_OK) {
            LOGE("[-] Failed to attach thread to JVM");
            return NULL;
        }
    } else if (status != JNI_OK) {
        LOGE("[-] GetEnv failed: %d", status);
        return NULL;
    }
    return env;
}

/* Get the Application Context via ActivityThread */
static jobject get_app_context(JNIEnv* env) {
    if (!env) return NULL;

    jclass activityThreadClass = (*env)->FindClass(env, "android/app/ActivityThread");
    if (!activityThreadClass) {
        LOGE("[-] ActivityThread class not found");
        return NULL;
    }

    jmethodID currentActivityThread = (*env)->GetStaticMethodID(
        env, activityThreadClass, "currentActivityThread",
        "()Landroid/app/ActivityThread;");
    if (!currentActivityThread) return NULL;

    jobject activityThread = (*env)->CallStaticObjectMethod(
        env, activityThreadClass, currentActivityThread);
    if (!activityThread) return NULL;

    jmethodID getApplication = (*env)->GetMethodID(
        env, activityThreadClass, "getApplication",
        "()Landroid/app/Application;");
    if (!getApplication) {
        (*env)->DeleteLocalRef(env, activityThread);
        return NULL;
    }

    jobject app = (*env)->CallObjectMethod(env, activityThread, getApplication);
    (*env)->DeleteLocalRef(env, activityThread);
    return app;
}

/* Get ClipboardManager system service */
static jobject get_clipboard_manager(JNIEnv* env) {
    jobject app = get_app_context(env);
    if (!app) return NULL;

    jclass contextClass = (*env)->FindClass(env, "android/content/Context");
    jfieldID field = (*env)->GetStaticFieldID(
        env, contextClass, "CLIPBOARD_SERVICE", "Ljava/lang/String;");
    jstring serviceName = (jstring)(*env)->GetStaticObjectField(env, contextClass, field);

    jmethodID getSystemService = (*env)->GetMethodID(
        env, contextClass, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;");
    jobject manager = (*env)->CallObjectMethod(env, app, getSystemService, serviceName);

    (*env)->DeleteLocalRef(env, app);
    (*env)->DeleteLocalRef(env, serviceName);
    return manager;
}

/* ---- Public API ---- */

int clipboard_set(const char* text) {
    if (!text) return -1;

    JavaVM* vm = get_jvm();
    if (!vm) return -1;

    JNIEnv* env = get_env(vm);
    if (!env) return -1;

    jobject manager = get_clipboard_manager(env);
    if (!manager) return -1;

    /* ClipData.newPlainText("Xinject", text) */
    jclass clipDataClass = (*env)->FindClass(env, "android/content/ClipData");
    jstring label = (*env)->NewStringUTF(env, "Xinject");
    jstring jtext = (*env)->NewStringUTF(env, text);

    jmethodID newPlainText = (*env)->GetStaticMethodID(
        env, clipDataClass, "newPlainText",
        "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;");
    jobject clipData = (*env)->CallStaticObjectMethod(
        env, clipDataClass, newPlainText, label, jtext);

    /* manager.setPrimaryClip(clipData) */
    jclass mgrClass = (*env)->GetObjectClass(env, manager);
    jmethodID setPrimaryClip = (*env)->GetMethodID(
        env, mgrClass, "setPrimaryClip", "(Landroid/content/ClipData;)V");
    (*env)->CallVoidMethod(env, manager, setPrimaryClip, clipData);

    /* Cleanup */
    (*env)->DeleteLocalRef(env, jtext);
    (*env)->DeleteLocalRef(env, label);
    (*env)->DeleteLocalRef(env, clipData);
    (*env)->DeleteLocalRef(env, manager);

    return 0;
}

char* clipboard_get(void) {
    JavaVM* vm = get_jvm();
    if (!vm) return strdup("");

    JNIEnv* env = get_env(vm);
    if (!env) return strdup("");

    jobject manager = get_clipboard_manager(env);
    if (!manager) return strdup("");

    /* Get primary clip */
    jclass mgrClass = (*env)->GetObjectClass(env, manager);
    jmethodID getPrimaryClip = (*env)->GetMethodID(
        env, mgrClass, "getPrimaryClip", "()Landroid/content/ClipData;");
    jobject clipData = (*env)->CallObjectMethod(env, manager, getPrimaryClip);

    if (!clipData) {
        (*env)->DeleteLocalRef(env, manager);
        return strdup("");
    }

    /* Get item count */
    jclass clipDataClass = (*env)->GetObjectClass(env, clipData);
    jmethodID getItemCount = (*env)->GetMethodID(
        env, clipDataClass, "getItemCount", "()I");
    int count = (*env)->CallIntMethod(env, clipData, getItemCount);

    if (count == 0) {
        (*env)->DeleteLocalRef(env, clipData);
        (*env)->DeleteLocalRef(env, manager);
        return strdup("");
    }

    /* Get item at index 0 */
    jmethodID getItemAt = (*env)->GetMethodID(
        env, clipDataClass, "getItemAt",
        "(I)Landroid/content/ClipData$Item;");
    jobject item = (*env)->CallObjectMethod(env, clipData, getItemAt, 0);

    char* result = strdup("");
    if (item) {
        jclass itemClass = (*env)->GetObjectClass(env, item);
        jmethodID getText = (*env)->GetMethodID(
            env, itemClass, "getText", "()Ljava/lang/CharSequence;");
        jobject charSequence = (*env)->CallObjectMethod(env, item, getText);

        if (charSequence) {
            jclass csClass = (*env)->GetObjectClass(env, charSequence);
            jmethodID toString = (*env)->GetMethodID(
                env, csClass, "toString", "()Ljava/lang/String;");
            jstring jstr = (jstring)(*env)->CallObjectMethod(env, charSequence, toString);

            const char* utf = (*env)->GetStringUTFChars(env, jstr, NULL);
            if (utf) {
                free(result);
                result = strdup(utf);
                (*env)->ReleaseStringUTFChars(env, jstr, utf);
            }
            (*env)->DeleteLocalRef(env, charSequence);
        }
        (*env)->DeleteLocalRef(env, item);
    }

    (*env)->DeleteLocalRef(env, clipData);
    (*env)->DeleteLocalRef(env, manager);
    return result;
}
